(function($) {
$(document).ready(function(){
	
  $('li.expanded.dropdown ').hover(function() {
  $(this).find('ul.menu.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
   }, function() {
  $(this).find('ul.menu.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
  });
});

})(jQuery);

